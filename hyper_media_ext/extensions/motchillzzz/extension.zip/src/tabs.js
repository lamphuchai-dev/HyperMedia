async function tabs() {
  return Response.success([
    {
      title: "Phim mới cập nhật",
      url: "/phim-moi",
    },
  ]);
}
